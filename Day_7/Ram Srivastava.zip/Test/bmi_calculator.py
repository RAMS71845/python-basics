def bmi(weight_kg,height_m):
    # weight_kg=int(input("Enter Your weight"))
    # height_m=int( input("Enter your height"))
    bmi=weight_kg/(height_m**2)
    return bmi
print(f"expected : {bmi(72,1.75):.1f}")
